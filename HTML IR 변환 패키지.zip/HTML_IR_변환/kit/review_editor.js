/* 검토용 파일 편집 모드. finalize.py 가 …_검토용.html 에만 넣는다 (deck_base.html 은 고치지 않는다).
   E 키로 켜고 끈다. 꺼져 있으면 발표 화면과 똑같이 동작한다.
   켜면: 클릭 선택 · 드래그 이동 · 테두리 손잡이로 크기(Shift: 비율 유지) · 더블클릭(또는 Enter)으로 글 수정 · Delete 삭제
         Alt+↑/↓ 상위·하위 선택 · 화살표 1px(Shift 10px) 이동 · Ctrl+Z/Y 되돌리기·다시 · Ctrl+S 저장
         서식 줄: 굵게(Ctrl+B) · 글자색 · 채우기 · 글꼴(PC에 설치된 글꼴만) / 도형 넣기: 덱 색 토큰으로 그린 사각형·원·선·화살표·배지·글상자
   저장 파일은 발표 스크립트가 바꾸기 전의 원래 HTML에 편집 내용만 얹어 만든다. */
(function () {
  'use strict';
  var me = document.currentScript, stage = document.getElementById('stage');
  if (!me || !stage) return;

  /* ---------- 1. 원래 상태 기록 (이 스크립트는 발표 스크립트보다 먼저 실행된다) ---------- */
  var seq = 0;
  [].forEach.call(stage.querySelectorAll('*'), function (el) { el.setAttribute('data-eid', String(++seq)); });
  var bodyAttrs = [].map.call(document.body.attributes, function (a) { return [a.name, a.value]; });
  var pristine = [];
  for (var nd = document.body.firstChild; nd && nd !== me; nd = nd.nextSibling) pristine.push(nd.cloneNode(true));

  var MEDIA = /^(img|svg|canvas|video|picture)$/i;
  var PROPS = ['translate', 'width', 'height', 'flex', 'max-width', 'min-width', 'box-sizing', 'font-size',
    'color', 'background', 'font-family', 'font-weight'];
  var on = false, sel = null, editing = null, svgIn = null, drag = null, dirty = false;
  var ops = [], redoOps = [], origHtml = {}, touched = {}, chain = [];
  var bar, box, hov, toast, cnt, fmt, lastRange = null, inserted = {}, nseq = 0;

  function eid(el) { return el && el.getAttribute && el.getAttribute('data-eid'); }
  function byId(id) { return stage.querySelector('[data-eid="' + id + '"]'); }
  function scale() { return stage.getBoundingClientRect().width / stage.offsetWidth || 1; }
  function inSvg(el) { return el instanceof SVGElement; }
  function activeSlide() { return stage.querySelector('.slide.active'); }
  function isField(t) { return t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)); }
  function ui(t) { return t && t.closest && t.closest('#ed-top,#ed-box,.ed-in'); }

  function clean(el) {
    var c = el.cloneNode(true);
    [].forEach.call(c.querySelectorAll('.glare'), function (g) { g.remove(); });
    [].forEach.call(c.querySelectorAll('[contenteditable]'), function (g) { g.removeAttribute('contenteditable'); });
    return c.innerHTML;
  }
  function snap(el, html) {
    return { style: el.getAttribute('style'), del: el.hasAttribute('data-ed-del'), html: html ? el.innerHTML : null };
  }
  function restore(el, s) {
    if (s.style === null) el.removeAttribute('style'); else el.setAttribute('style', s.style);
    if (s.del) el.setAttribute('data-ed-del', ''); else el.removeAttribute('data-ed-del');
    if (s.html !== null) el.innerHTML = s.html;
  }

  /* ---------- 2. 되돌리기 기록 ---------- */
  function push(el, before, kind) {
    var id = eid(el), last = ops[ops.length - 1], html = before.html !== null;
    touched[id] = true;
    if (kind === 'nudge' && last && last.kind === 'nudge' && last.id === id && Date.now() - last.t < 1200) {
      last.after = snap(el, false); last.t = Date.now();
    } else {
      ops.push({ id: id, kind: kind, before: before, after: snap(el, html), t: Date.now() });
    }
    redoOps = []; dirty = true; status();
  }
  function step(from, to, key) {
    var op = from.pop(); if (!op) return;
    var el = byId(op.id); if (!el) return;
    restore(el, op[key]); to.push(op); dirty = true;
    select(el.hasAttribute('data-ed-del') ? null : el); status();
  }
  function undo() { endText(); step(ops, redoOps, 'before'); }
  function redo() { endText(); step(redoOps, ops, 'after'); }

  /* ---------- 3. 선택 · 상자 ---------- */
  function pick(t) {
    var sl = activeSlide();
    if (!sl || !t || !sl.contains(t) || t === sl) return null;
    if (inSvg(t)) { var s = t.closest('svg'); while (s && s.parentElement && s.parentElement.closest('svg')) s = s.parentElement.closest('svg'); t = s; }
    while (t && t !== sl && (!eid(t) || (getComputedStyle(t).display === 'inline' && !MEDIA.test(t.tagName)))) t = t.parentElement;
    /* 사진 틀(사진 하나만 든 상자)은 틀째로 잡아야 이동·크기 조절이 보이는 대로 된다 */
    if (t && MEDIA.test(t.tagName) && t.parentElement !== sl && t.parentElement.children.length === 1 && eid(t.parentElement)) t = t.parentElement;
    return t && t !== sl ? t : null;
  }
  function place(b, el) {
    if (!el) { b.style.display = 'none'; return; }
    var r = el.getBoundingClientRect(), st = b.style;
    st.display = 'block'; st.left = r.left + 'px'; st.top = r.top + 'px'; st.width = r.width + 'px'; st.height = r.height + 'px';
  }
  function select(el) { sel = el; chain = []; place(box, sel); status(); }
  function refresh() {
    if (sel && (!document.contains(sel) || !sel.closest('.slide.active'))) select(null);
    place(box, sel);
  }

  /* ---------- 4. 글 수정 ---------- */
  function textTarget(t) {
    var sl = activeSlide();
    while (t && t !== sl && (!eid(t) || getComputedStyle(t).display === 'inline')) t = t.parentElement;
    return t && t !== sl && t.textContent.trim() ? t : null;
  }
  function startText(el, x, y) {
    if (!el) return;
    endText();
    var id = eid(el);
    if (!(id in origHtml)) origHtml[id] = clean(el);
    editing = el; editing._before = snap(el, true);
    el.setAttribute('contenteditable', 'true'); el.focus();
    var r = x != null && document.caretRangeFromPoint && document.caretRangeFromPoint(x, y);
    if (r && el.contains(r.startContainer)) { var s = getSelection(); s.removeAllRanges(); s.addRange(r); }
    select(el);
  }
  function fixCounts(el) {
    [].forEach.call([el].concat([].slice.call(el.querySelectorAll('[data-count]'))), function (c) {
      if (!c.hasAttribute || !c.hasAttribute('data-count')) return;
      var a = c.getAttribute('data-count'), dec = (a.split('.')[1] || '').length, n = parseFloat(a);
      var shown = dec ? n.toFixed(dec) : Math.round(n).toLocaleString(), now = c.textContent.trim();
      if (now === shown) return;
      var v = now.replace(/,/g, '');
      if (/^-?\d+(\.\d+)?$/.test(v)) c.setAttribute('data-count', v); else c.removeAttribute('data-count');
    });
  }
  function endText() {
    if (svgIn) svgIn.commit();
    if (!editing) return;
    var el = editing, before = el._before; editing = null;
    el.removeAttribute('contenteditable'); delete el._before;
    if (el.innerHTML !== before.html || el.getAttribute('style') !== before.style) { fixCounts(el); push(el, before, 'text'); }
    lastRange = null;
    refresh();
  }
  function svgText(t) {
    var el = t.closest('tspan') || t.closest('text');
    if (!el || !eid(el)) return;
    endText();
    var id = eid(el), r = el.getBoundingClientRect(), inp = document.createElement('input');
    if (!(id in origHtml)) origHtml[id] = clean(el);
    var before = snap(el, true);
    inp.className = 'ed-in'; inp.value = el.textContent;
    inp.style.cssText = 'left:' + r.left + 'px;top:' + (r.top - 4) + 'px;width:' + Math.max(160, r.width + 40) + 'px';
    document.body.appendChild(inp); inp.focus(); inp.select();
    svgIn = {
      commit: function () {
        if (!svgIn) return; svgIn = null; var v = inp.value; inp.remove();
        if (v !== el.textContent) { el.textContent = v; push(el, before, 'text'); }
      },
      cancel: function () { svgIn = null; inp.remove(); }
    };
    inp.addEventListener('blur', function () { if (svgIn) svgIn.commit(); });
  }

  /* ---------- 5. 이동 · 크기 · 글자 크기 · 삭제 ---------- */
  function getT(el) { var p = (el.style.translate || '0px 0px').split(/\s+/); return [parseFloat(p[0]) || 0, parseFloat(p[1]) || 0]; }
  function setT(el, x, y) { el.style.translate = (x || y) ? Math.round(x) + 'px ' + Math.round(y) + 'px' : ''; }
  function nudge(dx, dy) { var b = snap(sel, false), t = getT(sel); setT(sel, t[0] + dx, t[1] + dy); push(sel, b, 'nudge'); refresh(); }
  function sizeFont(d) {
    if (!sel) return;
    var b = snap(sel, false), px = parseFloat(getComputedStyle(sel).fontSize) || 16;
    sel.style.fontSize = Math.max(13, px + d) + 'px'; push(sel, b, 'font'); refresh();
  }
  function del() {
    if (!sel) return;
    var b = snap(sel, false), el = sel;
    el.setAttribute('data-ed-del', ''); el.style.setProperty('display', 'none', 'important');
    push(el, b, 'del'); select(null);
  }
  function climb(up) {
    if (!sel) return;
    if (up) {
      var p = sel.parentElement;
      if (p && eid(p) && !p.classList.contains('slide')) { var c = chain.concat([sel]); select(p); chain = c; }
    } else if (chain.length) { var last = chain.pop(), rest = chain; select(last); chain = rest; }
  }

  function down(e) {
    var h = e.target.getAttribute && e.target.getAttribute('data-h');
    if (!on || e.button !== 0 || (!h && ui(e.target))) return;
    if (editing && editing.contains(e.target)) return;
    if (!h && !stage.contains(e.target)) return;
    e.preventDefault(); e.stopPropagation();
    endText();
    if (!h) { var el = pick(e.target); if (el !== sel) select(el); }
    if (!sel) return;
    var r = sel.getBoundingClientRect(), k = scale();
    drag = { h: h, x: e.clientX, y: e.clientY, t: getT(sel), w: r.width / k, ht: r.height / k, b: snap(sel, false), moved: false };
  }
  function move(e) {
    if (!on) return;
    e.stopPropagation();
    if (!drag) { if (!editing) place(hov, stage.contains(e.target) ? pick(e.target) : null); return; }
    var k = scale(), dx = (e.clientX - drag.x) / k, dy = (e.clientY - drag.y) / k;
    if (!drag.moved && Math.abs(dx) + Math.abs(dy) < 3) return;
    drag.moved = true; place(hov, null);
    if (!drag.h) setT(sel, drag.t[0] + dx, drag.t[1] + dy);
    else {
      var p = sel.parentElement && getComputedStyle(sel.parentElement).display;
      sel.style.boxSizing = 'border-box'; sel.style.maxWidth = 'none'; sel.style.minWidth = '0';
      if (p && /flex/.test(p)) sel.style.flex = 'none';
      if (drag.h === 'se' && e.shiftKey) dy = dx * drag.ht / drag.w;  /* Shift: 가로세로 비율 유지 */
      if (/e/.test(drag.h)) sel.style.width = Math.max(20, Math.round(drag.w + dx)) + 'px';
      if (/s/.test(drag.h)) sel.style.height = Math.max(12, Math.round(drag.ht + dy)) + 'px';
    }
    place(box, sel);
  }
  function up() {
    if (!drag) return;
    if (drag.moved) push(sel, drag.b, drag.h ? 'size' : 'move');
    drag = null; refresh();
  }


  /* ---------- 5-2. 서식: 굵게 · 글자색 · 채우기 · 글꼴 ---------- */
  document.addEventListener('selectionchange', function () {
    if (!editing) return;
    var s = getSelection();
    if (s.rangeCount && editing.contains(s.getRangeAt(0).commonAncestorContainer)) lastRange = s.getRangeAt(0).cloneRange();
  });
  function useRange() {  /* 글을 고치는 중 드래그로 고른 부분이 있으면 그 범위를 되살려 돌려준다 */
    if (!editing || !lastRange || lastRange.collapsed || !editing.contains(lastRange.commonAncestorContainer)) return null;
    editing.focus();
    var s = getSelection(); s.removeAllRanges(); s.addRange(lastRange);
    return lastRange;
  }
  function wrapRange(prop, val) {
    var r = useRange(); if (!r) return false;
    var sp = document.createElement('span');
    sp.style.setProperty(prop, val || 'inherit');
    sp.appendChild(r.extractContents());
    [].forEach.call(sp.querySelectorAll('[style]'), function (x) { x.style.removeProperty(prop); if (!x.getAttribute('style')) x.removeAttribute('style'); });
    r.insertNode(sp);
    var nr = document.createRange(); nr.selectNodeContents(sp);
    var s = getSelection(); s.removeAllRanges(); s.addRange(nr); lastRange = nr.cloneRange();
    return true;
  }
  function setProp(el, prop, val) { if (val) el.style.setProperty(prop, val); else el.style.removeProperty(prop); }
  function applyStyle(prop, val, wholeBox) {
    if (editing) {
      if (wholeBox || !wrapRange(prop, val)) setProp(editing, prop, val);
      refresh(); return;
    }
    if (!sel) return;
    var b = snap(sel, false); setProp(sel, prop, val); push(sel, b, 'style'); refresh();
  }
  function bold() {
    if (editing && useRange()) { document.execCommand('bold'); return; }
    var el = editing || sel; if (!el) return;
    applyStyle('font-weight', (parseInt(getComputedStyle(el).fontWeight, 10) || 400) >= 600 ? '400' : '700', true);
  }
  var FONTS = ['Pretendard', '맑은 고딕', 'Malgun Gothic', '나눔고딕', 'NanumGothic', '나눔명조', 'NanumMyeongjo', '나눔스퀘어', 'NanumSquare',
    '나눔바른고딕', 'NanumBarunGothic', 'Noto Sans KR', 'Noto Serif KR', 'Spoqa Han Sans Neo', 'IBM Plex Sans KR', 'Gmarket Sans', 'GmarketSans',
    'KoPub돋움체 Medium', 'KoPubDotum', '바탕', 'Batang', '돋움', 'Dotum', '굴림', 'Gulim', '궁서', 'Gungsuh', 'Apple SD Gothic Neo',
    'Arial', 'Calibri', 'Segoe UI', 'Helvetica', 'Times New Roman', 'Georgia', 'Verdana', 'Tahoma', 'Consolas', 'Montserrat', 'Roboto'];
  function installed(name) {
    var c = document.createElement('canvas').getContext('2d'), t = '가나다라 AaMmWw 123';
    return ['monospace', 'serif', 'sans-serif'].some(function (f) {
      c.font = '40px ' + f; var w = c.measureText(t).width;
      c.font = '40px "' + name + '", ' + f; return c.measureText(t).width !== w;
    });
  }
  function fillFonts(list, note) {
    var box = fmt.querySelector('.fl'), seen = {};
    list = list.filter(function (n) { if (seen[n]) return false; seen[n] = 1; return true; })
      .sort(function (a, b) { var ka = /[가-힣]/.test(a) ? 0 : 1, kb = /[가-힣]/.test(b) ? 0 : 1; return ka - kb || a.localeCompare(b, 'ko'); });
    box.innerHTML = '<div class="fn" data-f="">덱 기본 글꼴 (Pretendard)</div>' + list.map(function (n) {
      var q = n.replace(/"/g, ''); return '<div class="fn" data-f="' + q + '" style="font-family:&quot;' + q + '&quot;,sans-serif">' + q + '</div>';
    }).join('');
    fmt.querySelector('.fnote').textContent = note + ' · ' + list.length + '개';
  }
  function openFonts() {
    var pnl = fmt.querySelector('.fp'), open = !pnl.classList.contains('on');
    pnl.classList.toggle('on', open);
    if (!open || pnl.getAttribute('data-ok')) return;
    pnl.setAttribute('data-ok', '1');
    var fallback = function () { fillFonts(FONTS.filter(installed), '이 PC에서 찾은 글꼴'); };
    if (!window.queryLocalFonts) { fallback(); return; }
    window.queryLocalFonts().then(function (fs) {
      var fam = fs.map(function (f) { return f.family; });
      if (fam.length) fillFonts(fam, '이 PC에 설치된 글꼴'); else fallback();
    }).catch(fallback);
  }
  function setFont(name) {
    fmt.querySelector('.fp').classList.remove('on');
    applyStyle('font-family', name ? '"' + name + '", var(--font, sans-serif)' : '');
    if (name) say('다른 PC에 이 글꼴이 없으면 기본 글꼴로 보입니다');
  }

  /* ---------- 5-3. 도형 넣기 (덱 색 토큰을 쓴다) ---------- */
  var SHAPES = {
    box: ['사각형', 'width:280px;height:160px;border-radius:14px;background:var(--tint)'],
    navy: ['진한 사각형', 'width:280px;height:160px;border-radius:14px;background:var(--navy);color:#fff'],
    frame: ['테두리 사각형', 'width:280px;height:160px;border-radius:14px;border:2px solid currentColor;color:var(--navy)'],
    circle: ['원', 'width:160px;height:160px;border-radius:50%;background:var(--tint);border:2px solid currentColor;color:var(--navy)'],
    line: ['선', 'width:300px;height:24px;display:flex;align-items:center;color:var(--navy)', '<i style="flex:1;border-top:3px solid currentColor;pointer-events:none"></i>'],
    arrow: ['화살표', 'width:300px;height:24px;display:flex;align-items:center;color:var(--navy)',
      '<i style="flex:1;border-top:3px solid currentColor;pointer-events:none"></i><i style="width:0;height:0;border-left:16px solid currentColor;border-top:9px solid transparent;border-bottom:9px solid transparent;pointer-events:none"></i>'],
    badge: ['번호 배지', 'width:44px;height:44px;border-radius:50%;background:var(--navy);color:#fff;display:grid;place-items:center;font-weight:700;font-size:20px', '1'],
    text: ['글상자', 'width:420px;min-height:40px;padding:6px 10px;font-size:var(--fs-body);line-height:1.55;color:var(--ink)', '텍스트']
  };
  function addShape(k) {
    var sl = activeSlide(), d = SHAPES[k]; if (!sl || !d) return;
    endText();
    var el = document.createElement('div'), id = 'n' + (++nseq);
    el.className = 'ed-shape';
    el.setAttribute('style', 'position:absolute;left:0;top:0;z-index:6;box-sizing:border-box;' + d[1]);
    el.innerHTML = d[2] || '';
    el.setAttribute('data-eid', id);
    [].forEach.call(el.querySelectorAll('*'), function (c, i) { c.setAttribute('data-eid', id + '_' + i); });
    sl.appendChild(el);
    var w = el.offsetWidth, h = el.offsetHeight;
    el.style.left = Math.round((sl.offsetWidth - w) / 2) + 'px'; el.style.top = Math.round((sl.offsetHeight - h) / 2) + 'px';
    inserted[id] = eid(sl);
    push(el, { style: el.getAttribute('style') + ';display:none !important', del: true, html: null }, 'insert');
    select(el);
    if (k === 'text' || k === 'badge') { startText(el); document.execCommand('selectAll'); }
    fmt.querySelector('.sm').classList.remove('on');
  }

  /* ---------- 6. 저장 ---------- */
  function buildHtml() {
    var frag = document.createDocumentFragment();
    pristine.forEach(function (n) { frag.appendChild(n.cloneNode(true)); });
    function map() { var m = {}; [].forEach.call(frag.querySelectorAll('[data-eid]'), function (e) { m[eid(e)] = e; }); return m; }
    function mark(p) { var sec = p.closest('section.slide'); if (sec) sec.setAttribute('data-edited', '1'); }
    var pm = map();
    Object.keys(origHtml).forEach(function (id) {
      var live = byId(id), p = pm[id];
      if (live && p) { var h = clean(live); if (h !== origHtml[id]) { p.innerHTML = h; mark(p); } }
    });
    pm = map();
    Object.keys(touched).forEach(function (id) {
      var live = byId(id), p = pm[id];
      if (!live || !p) return;
      if (live.hasAttribute('data-ed-del')) { mark(p); p.remove(); return; }
      var was = p.getAttribute('style') || '';
      PROPS.forEach(function (k) { var v = live.style.getPropertyValue(k); if (v) p.style.setProperty(k, v); else p.style.removeProperty(k); });
      if (!p.getAttribute('style')) p.removeAttribute('style');
      if ((p.getAttribute('style') || '') !== was) mark(p);
    });
    pm = map();
    Object.keys(inserted).forEach(function (id) {
      var live = byId(id), host = pm[inserted[id]];
      if (!live || !host || live.hasAttribute('data-ed-del')) return;
      var c = live.cloneNode(true); c.removeAttribute('contenteditable');
      [].forEach.call(c.querySelectorAll('[contenteditable]'), function (g) { g.removeAttribute('contenteditable'); });
      host.appendChild(c); mark(host);
    });
    [].forEach.call(frag.querySelectorAll('[data-eid]'), function (e) { e.removeAttribute('data-eid'); });
    var wrap = document.createElement('div'); wrap.appendChild(frag);
    var scripts = [];
    for (var s = me; s; s = s.nextSibling) if (s.nodeType === 1 && s.tagName === 'SCRIPT') scripts.push(s.outerHTML);
    var head = document.head.cloneNode(true), css = head.querySelector('#ed-css');
    if (css) css.remove();
    var attrs = function (list) { return list.map(function (a) { return ' ' + a[0] + '="' + a[1].replace(/&/g, '&amp;').replace(/"/g, '&quot;') + '"'; }).join(''); };
    var htmlAttrs = [].map.call(document.documentElement.attributes, function (a) { return [a.name, a.value]; });
    return '<!DOCTYPE html>\n<html' + attrs(htmlAttrs) + '>' + head.outerHTML + '\n<body' + attrs(bodyAttrs) + '>' +
      wrap.innerHTML + '\n' + scripts.join('\n') + '\n</bo' + 'dy></ht' + 'ml>\n';  /* 글자를 나눠 써서 finalize 의 </body> 찾기에 걸리지 않게 함 */
  }
  function fileName() {
    var n = decodeURIComponent((location.pathname.split('/').pop() || 'deck.html'));
    n = n.replace(/(_검토용|_편집본)?\.html?$/i, '');
    return n + '_편집본.html';
  }
  function save() {
    endText();
    var html = buildHtml(), name = fileName();
    var done = function (n) { dirty = false; status(); say('저장했습니다: ' + n); };
    var fallback = function () {
      var a = document.createElement('a'), url = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
      a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000); done(name + ' (다운로드 폴더)');
    };
    if (!window.showSaveFilePicker) { fallback(); return; }
    window.showSaveFilePicker({ suggestedName: name, types: [{ description: 'HTML', accept: { 'text/html': ['.html'] } }] })
      .then(function (h) { return h.createWritable().then(function (w) { return w.write(html).then(function () { return w.close(); }); }).then(function () { done(h.name); }); })
      .catch(function (err) { if (err && err.name === 'AbortError') return; fallback(); });
  }
  window.KIT_EDIT_HTML = buildHtml;

  /* ---------- 7. 화면 (도구 막대) ---------- */
  function say(t) { toast.textContent = t; toast.style.opacity = '1'; clearTimeout(say.t); say.t = setTimeout(function () { toast.style.opacity = '0'; }, 2600); }
  function status() {
    if (!cnt) return;
    cnt.textContent = '변경 ' + ops.length + '건' + (dirty ? ' · 저장 안 됨' : ' · 저장됨');
    bar.querySelector('[data-a=undo]').disabled = !ops.length;
    bar.querySelector('[data-a=redo]').disabled = !redoOps.length;
    [].forEach.call(bar.querySelectorAll('.need'), function (b) { b.disabled = !sel; });
    if (fmt) fmt.classList.toggle('show', on && !!(sel || editing));
  }
  function setOn(v) {
    on = v; document.body.classList.toggle('ed-on', on);
    if (!on) { endText(); select(null); place(hov, null); }
    say(on ? '편집 모드 켜짐 · 다시 E 키를 누르면 꺼집니다' : '편집 모드 꺼짐');
    status();
  }
  function build() {
    var css = document.createElement('style'); css.id = 'ed-css';
    css.textContent = [
      '#ed-top{position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:9999;display:none;flex-direction:column;align-items:center;gap:6px}',
      'body.ed-on #ed-top{display:flex}#ed-bar b{cursor:move;user-select:none}',
      '#ed-bar{display:flex;align-items:center;gap:6px;padding:8px 10px;border-radius:12px;background:var(--navy-d);color:#fff;font:600 13px "PretendardKit",Pretendard,sans-serif;box-shadow:0 10px 28px rgba(0,0,0,.28);white-space:nowrap}',
      '#ed-bar b{color:var(--orange);margin-right:4px}#ed-bar .c{opacity:.8;margin:0 6px;font-weight:500}',
      '#ed-bar button{border:0;border-radius:7px;padding:6px 10px;background:var(--btn);color:#fff;font:inherit;cursor:pointer}',
      '#ed-bar button:hover{filter:brightness(1.15)}#ed-bar button:disabled{opacity:.35;cursor:default;filter:none}',
      '#ed-bar button.pri{background:var(--orange)}#ed-bar .sep{width:1px;height:20px;background:rgba(255,255,255,.25);margin:0 2px}',
      '#ed-box,#ed-hov{position:fixed;display:none;pointer-events:none;z-index:9997}',
      '#ed-box{border:2px solid var(--orange)}#ed-hov{border:1px dashed var(--orange);opacity:.7}',
      '#ed-box i{position:absolute;width:12px;height:12px;border-radius:3px;background:#fff;border:2px solid var(--orange);pointer-events:auto}',
      '#ed-box i[data-h=e]{right:-7px;top:50%;margin-top:-6px;cursor:ew-resize}#ed-box i[data-h=s]{bottom:-7px;left:50%;margin-left:-6px;cursor:ns-resize}',
      '#ed-box i[data-h=se]{right:-7px;bottom:-7px;cursor:nwse-resize}',
      'body.ed-on #stage{cursor:default}body.ed-on .tilt{transform:none!important}',
      '[contenteditable=true]{outline:2px solid var(--orange)!important;outline-offset:2px;cursor:text}',
      '.ed-in{position:fixed;z-index:10000;padding:4px 8px;border:2px solid var(--orange);border-radius:6px;font:500 15px "PretendardKit",Pretendard,sans-serif}',
      '#ed-toast{position:fixed;left:50%;bottom:64px;transform:translateX(-50%);z-index:10000;padding:9px 16px;border-radius:10px;background:var(--navy-d);color:#fff;font:600 14px "PretendardKit",Pretendard,sans-serif;opacity:0;transition:opacity .3s;pointer-events:none}',
      '#ed-fmt{display:flex;align-items:center;gap:6px;padding:7px 10px;border-radius:12px;background:#fff;color:var(--ink);font:600 13px "PretendardKit",Pretendard,sans-serif;box-shadow:0 10px 28px rgba(0,0,0,.2);white-space:nowrap}',
      '#ed-fmt .g{display:flex;align-items:center;gap:4px}#ed-fmt .lb{color:var(--sub);font-weight:500;margin-right:2px}',
      '#ed-fmt .sep{width:1px;height:20px;background:var(--line);margin:0 4px}',
      '#ed-fmt button{border:1px solid var(--line);border-radius:7px;padding:5px 9px;background:#fff;color:var(--ink);font:inherit;cursor:pointer}',
      '#ed-fmt button:hover{border-color:var(--orange)}#ed-fmt button.b{font-weight:800;min-width:30px}',
      '#ed-fmt .sw{width:20px;height:20px;padding:0;border-radius:50%;border:1px solid rgba(0,0,0,.18)}',
      '#ed-fmt .sw.none{background:linear-gradient(135deg,#fff 45%,var(--orange-d) 45% 55%,#fff 55%)}',
      '#ed-fmt input[type=color]{width:24px;height:22px;padding:0;border:0;background:none;cursor:pointer}',
      '#ed-fmt .shp,#ed-fmt .fw{position:relative}#ed-fmt .sm,#ed-fmt .fp{position:absolute;top:34px;left:0;display:none;background:#fff;border-radius:10px;box-shadow:0 10px 28px rgba(0,0,0,.22);padding:6px;z-index:2}',
      '#ed-fmt .sm.on,#ed-fmt .fp.on{display:block}#ed-fmt .sm button{display:block;width:100%;text-align:left;border:0;margin:1px 0}',
      '#ed-fmt .fp{width:280px}#ed-fmt .fp input{width:100%;padding:6px 8px;border:1px solid var(--line);border-radius:7px;font:inherit;margin-bottom:4px}',
      '#ed-fmt .fl{max-height:320px;overflow:auto}#ed-fmt .fn{padding:6px 8px;border-radius:6px;cursor:pointer;font-size:15px;font-weight:500}#ed-fmt .fn:hover{background:var(--tint)}',
      '#ed-fmt .fnote{color:var(--mute);font-size:12px;font-weight:500;padding:2px 4px 6px}',
      '@media print{#ed-top,#ed-box,#ed-hov,#ed-toast,.ed-in{display:none!important}}'
    ].join('\n');
    document.head.appendChild(css);
    bar = document.createElement('div'); bar.id = 'ed-bar';
    bar.innerHTML = '<b>⠿ 편집</b><button data-a="undo" title="되돌리기 (Ctrl+Z)">↶ 되돌리기</button><button data-a="redo" title="다시 (Ctrl+Y)">↷ 다시</button><span class="sep"></span>' +
      '<button class="need" data-a="text" title="글 수정 (더블클릭 · Enter)">글 수정</button><button class="need" data-a="parent" title="상위 선택 (Alt+↑)">상위 선택</button>' +
      '<button class="need" data-a="fm" title="글자 작게">가−</button><button class="need" data-a="fp" title="글자 크게">가+</button>' +
      '<button class="need" data-a="del" title="삭제 (Delete)">삭제</button><span class="sep"></span><span class="c"></span>' +
      '<button class="pri" data-a="save" title="저장 (Ctrl+S)">저장</button><button data-a="off" title="편집 끄기 (E)">끄기</button>';
    cnt = bar.querySelector('.c');
    bar.addEventListener('mousedown', function (e) { e.preventDefault(); });
    bar.addEventListener('click', function (e) {
      var a = e.target.getAttribute && e.target.getAttribute('data-a');
      if (a === 'undo') undo(); else if (a === 'redo') redo(); else if (a === 'save') save(); else if (a === 'off') setOn(false);
      else if (a === 'text') startText(textTarget(sel)); else if (a === 'parent') climb(true);
      else if (a === 'fm') sizeFont(-1); else if (a === 'fp') sizeFont(1); else if (a === 'del') del();
    });
    var TXT = [['var(--navy)', 'NP 남색'], ['var(--navy-d)', '진한 남색'], ['var(--orange)', 'NP 주황'], ['var(--orange-d)', '진한 주황'],
      ['var(--yellow)', '노랑'], ['var(--ink)', '본문색'], ['var(--mute)', '회색'], ['#fff', '흰색']];
    var FILL = [['', '채우기 없음'], ['var(--tint)', '연한 남색'], ['var(--paper)', '바탕색'], ['var(--navy)', 'NP 남색'], ['var(--navy-d)', '진한 남색'],
      ['var(--orange)', 'NP 주황'], ['var(--yellow)', '노랑'], ['#fff', '흰색']];
    var sw = function (list, kind) {
      return list.map(function (c) { return '<button class="sw' + (c[0] ? '' : ' none') + '" data-' + kind + '="' + c[0] + '" title="' + c[1] + '" style="' + (c[0] ? 'background:' + c[0] : '') + '"></button>'; }).join('') +
        '<input type="color" data-k="' + kind + '" title="직접 고르기">';
    };
    fmt = document.createElement('div'); fmt.id = 'ed-fmt';
    fmt.innerHTML = '<button class="b" data-a="bold" title="굵게 (Ctrl+B)">B</button><span class="sep"></span>' +
      '<span class="g"><span class="lb">글자색</span>' + sw(TXT, 'c') + '</span><span class="sep"></span>' +
      '<span class="g"><span class="lb">채우기</span>' + sw(FILL, 'f') + '</span><span class="sep"></span>' +
      '<span class="fw"><button data-a="font" title="PC에 설치된 글꼴">글꼴 ▾</button><div class="fp"><input placeholder="글꼴 이름 찾기"><div class="fnote">불러오는 중…</div><div class="fl"></div></div></span>' +
      '<span class="shp"><button data-a="shapes">도형 넣기 ▾</button><div class="sm">' +
      Object.keys(SHAPES).map(function (k) { return '<button data-shape="' + k + '">' + SHAPES[k][0] + '</button>'; }).join('') + '</div></span>';
    fmt.addEventListener('mousedown', function (e) { if (!/^(INPUT)$/.test(e.target.tagName)) e.preventDefault(); });
    fmt.addEventListener('click', function (e) {
      var t = e.target, a = t.getAttribute('data-a');
      if (a === 'bold') bold();
      else if (a === 'font') openFonts();
      else if (a === 'shapes') fmt.querySelector('.sm').classList.toggle('on');
      else if (t.hasAttribute('data-shape')) addShape(t.getAttribute('data-shape'));
      else if (t.hasAttribute('data-c')) applyStyle('color', t.getAttribute('data-c'));
      else if (t.hasAttribute('data-f') && t.classList.contains('sw')) applyStyle('background', t.getAttribute('data-f'), true);
      else if (t.classList.contains('fn')) setFont(t.getAttribute('data-f'));
    });
    fmt.addEventListener('change', function (e) {
      var k = e.target.getAttribute('data-k');
      if (k === 'c') applyStyle('color', e.target.value); else if (k === 'f') applyStyle('background', e.target.value, true);
    });
    fmt.querySelector('.fp input').addEventListener('input', function (e) {
      var q = e.target.value.trim().toLowerCase();
      [].forEach.call(fmt.querySelectorAll('.fn'), function (n) { n.style.display = !q || n.textContent.toLowerCase().indexOf(q) > -1 ? '' : 'none'; });
    });
    box = document.createElement('div'); box.id = 'ed-box'; box.innerHTML = '<i data-h="e"></i><i data-h="s"></i><i data-h="se"></i>';
    hov = document.createElement('div'); hov.id = 'ed-hov';
    toast = document.createElement('div'); toast.id = 'ed-toast';
    var top = document.createElement('div'); top.id = 'ed-top'; top.appendChild(bar); top.appendChild(fmt);
    document.body.appendChild(top); document.body.appendChild(box);
    bar.querySelector('b').title = '끌어서 도구 막대 옮기기';
    bar.querySelector('b').addEventListener('mousedown', function (e) {
      var r = top.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
      var mv = function (ev) { top.style.transform = 'none'; top.style.left = (ev.clientX - dx) + 'px'; top.style.top = (ev.clientY - dy) + 'px'; };
      var upf = function () { window.removeEventListener('mousemove', mv, true); window.removeEventListener('mouseup', upf, true); };
      window.addEventListener('mousemove', mv, true); window.addEventListener('mouseup', upf, true);
    }); document.body.appendChild(hov); document.body.appendChild(toast);
    var hint = document.getElementById('hint');
    if (hint) hint.textContent += ' · E 편집' + (window.KIT_ORIG ? ' · O 원본 비교' : '');
    status();
  }

  /* ---------- 8. 키보드 · 마우스 (발표 스크립트보다 먼저 받는다) ---------- */
  function key(e) {
    var c = e.code, ctrl = e.ctrlKey || e.metaKey, k = e.key;
    if (svgIn) {
      if (k === 'Enter') { e.preventDefault(); svgIn.commit(); } else if (k === 'Escape') { e.preventDefault(); svgIn.cancel(); }
      e.stopPropagation(); return;
    }
    if (editing) {
      if (k === 'Escape' || (k === 'Enter' && !e.shiftKey && !e.isComposing)) { e.preventDefault(); endText(); }
      else if (ctrl && c === 'KeyS') { e.preventDefault(); save(); }
      else if (ctrl && c === 'KeyB') { e.preventDefault(); bold(); }
      e.stopPropagation(); return;
    }
    if (isField(e.target)) return;
    if (c === 'KeyE' && !ctrl && !e.altKey) { e.preventDefault(); e.stopPropagation(); setOn(!on); return; }
    if (!on) return;
    var hit = true;
    if (ctrl && c === 'KeyZ') { if (e.shiftKey) redo(); else undo(); }
    else if (ctrl && c === 'KeyY') redo();
    else if (ctrl && c === 'KeyS') save();
    else if (!sel) hit = false;
    else if (ctrl && c === 'KeyB') bold();
    else if (k === 'Escape') select(null);
    else if (e.altKey && k === 'ArrowUp') climb(true);
    else if (e.altKey && k === 'ArrowDown') climb(false);
    else if (/^Arrow/.test(k)) { var d = e.shiftKey ? 10 : 1; nudge(k === 'ArrowLeft' ? -d : k === 'ArrowRight' ? d : 0, k === 'ArrowUp' ? -d : k === 'ArrowDown' ? d : 0); }
    else if (k === 'Delete' || k === 'Backspace') del();
    else if (k === 'Enter' || k === 'F2') startText(textTarget(sel));
    else hit = false;
    if (hit) { e.preventDefault(); e.stopPropagation(); }
  }
  function swallow(e) {
    if (!on || ui(e.target) || !stage.contains(e.target)) return;
    e.stopPropagation();
    if (!(editing && editing.contains(e.target))) e.preventDefault();
  }
  function dbl(e) {
    if (!on || !stage.contains(e.target)) return;
    e.preventDefault(); e.stopPropagation();
    if (inSvg(e.target)) { if (/^(text|tspan)$/.test(e.target.tagName)) svgText(e.target); return; }
    startText(textTarget(e.target), e.clientX, e.clientY);
  }
  function paste(e) {
    if (!editing || !editing.contains(e.target)) return;
    e.preventDefault();
    document.execCommand('insertText', false, (e.clipboardData || window.clipboardData).getData('text/plain'));
  }

  window.addEventListener('keydown', key, true);
  window.addEventListener('mousedown', down, true);
  window.addEventListener('mousemove', move, true);
  window.addEventListener('mouseup', up, true);
  window.addEventListener('click', swallow, true);
  window.addEventListener('dblclick', dbl, true);
  window.addEventListener('paste', paste, true);
  window.addEventListener('resize', function () { if (on) refresh(); });
  window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
  setInterval(function () { if (on && !drag) refresh(); }, 300);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
