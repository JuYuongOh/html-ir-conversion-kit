"""원본 PPTX·PDF와 결과 HTML의 글을 장별로 대조해 빠진 문장·숫자를 찾는다 (지침 상세 12장).

사용법:
    python tools/verify_text.py 원본.pptx|원본.pdf 결과.html [--report 대조결과.txt]
필요:
    PPTX: python-pptx / PDF: pdfplumber. 없으면 처음 실행할 때 자동으로 설치한다 (tools/deps.py).
원본에 없던 장(새로 넣은 표지·감사합니다 장)은 section 에 data-added 를 붙여 두면 대조에서 빠진다.
판정:
    빠짐      = 원본 문장이 결과 장에 없음 (꼭 확인)
    부분 일치 = 단어 90% 이상은 있으나 문장이 달라짐 (요약 문장으로 어미를 바꾼 경우 정상)
    옮김      = 단어·숫자가 차트 라벨·카운트업·탭 값으로 흩어져 들어감 (보통 정상, 눈으로 확인)
    빠진 숫자 = 원본 장의 숫자가 결과 장의 글·카운트업·차트 데이터 어디에도 없음
"""
import sys
import re
import argparse
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
from typing import Optional

import deps

sys.stdout.reconfigure(encoding='utf-8')

STRIP = re.compile(r'[\s ·•∙‧・\-–—"“”\'‘’()\[\]<>:;,.!?※*~|/]+')
NUM = re.compile(r'\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?')


def norm(t: str) -> str:
    return STRIP.sub('', t).lower()


def nums(t: str) -> set[str]:
    return {n.replace(',', '') for n in NUM.findall(t) if len(n.replace(',', '')) >= 2}


def pptx_paragraphs(path: Path) -> list[list[str]]:
    deps.ensure('pptx')
    try:
        from pptx import Presentation
        from pptx.enum.shapes import MSO_SHAPE_TYPE
    except ImportError:
        sys.exit('[오류] python-pptx 가 필요합니다: pip install python-pptx')
    try:
        prs = Presentation(str(path))
    except Exception as e:  # python-pptx raises several exception types for broken files
        sys.exit(f'[오류] PPTX 를 열 수 없습니다: {e}')

    def walk(shapes, out: list[str]) -> None:
        for sh in shapes:
            if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
                walk(sh.shapes, out)
                continue
            if getattr(sh, 'has_text_frame', False) and sh.has_text_frame:
                out.extend(p.text.strip() for p in sh.text_frame.paragraphs)
            if getattr(sh, 'has_table', False) and sh.has_table:
                for row in sh.table.rows:
                    out.extend(c.text.strip() for c in row.cells)

    slides = []
    for s in prs.slides:
        out: list[str] = []
        walk(s.shapes, out)
        slides.append([t for t in out if t and not re.fullmatch(r'\d{1,3}', t)])
    return slides


def pdf_paragraphs(path: Path) -> list[list[str]]:
    """PDF는 쪽마다 줄 단위로 읽는다 (줄 끝에서 문장이 끊겨도 줄 단위로 대조하므로 결과는 같다)."""
    pages: list[str] = []
    deps.ensure('pdfplumber')
    try:
        import pdfplumber
        try:
            with pdfplumber.open(str(path)) as pdf:
                pages = [pg.extract_text() or '' for pg in pdf.pages]
        except Exception as e:  # pdfplumber/pdfminer raise many parser-specific errors
            sys.exit(f'[오류] PDF 를 열 수 없습니다: {e}')
    except ImportError:
        try:
            from pypdf import PdfReader
        except ImportError:
            sys.exit('[오류] PDF 를 읽으려면 pip install pdfplumber (또는 pypdf) 가 필요합니다.')
        try:
            pages = [pg.extract_text() or '' for pg in PdfReader(str(path)).pages]
        except Exception as e:  # pypdf raises several error types for broken files
            sys.exit(f'[오류] PDF 를 열 수 없습니다: {e}')
    if pages and not any(t.strip() for t in pages):
        print('[경고] PDF 에서 글을 뽑지 못했습니다 (이미지로 된 PDF일 수 있음). 눈으로 대조하세요.')
    return [[ln.strip() for ln in t.splitlines() if ln.strip() and not re.fullmatch(r'\d{1,3}', ln.strip())] for t in pages]


class SectionText(HTMLParser):
    """<section class="slide …"> 마다 화면 글 + data-count/data-vals 값 + 차트 스크립트 숫자를 모은다."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.slides: list[dict[str, list[str]]] = []
        self.depth = 0
        self.skip: Optional[str] = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'section' and 'slide' in (a.get('class') or '').split():
            self.slides.append({'text': [], 'extra': [], 'added': 'data-added' in a})
            self.depth = 1
            return
        if not self.slides or self.depth == 0:
            return
        if tag == 'section':
            self.depth += 1
        if tag in ('style', 'script'):
            self.skip = tag
        for k in ('data-count', 'data-vals', 'alt'):
            if a.get(k):
                self.slides[-1]['extra'].append(a[k])

    def handle_endtag(self, tag):
        if tag == self.skip:
            self.skip = None
        if tag == 'section' and self.depth:
            self.depth -= 1

    def handle_data(self, data):
        if not self.slides or self.depth == 0:
            return
        key = 'extra' if self.skip == 'script' else ('text' if self.skip is None else None)
        if key:
            self.slides[-1][key].append(data)


def main() -> None:
    ap = argparse.ArgumentParser(description='원본 PPTX·PDF 와 결과 HTML 의 글을 장별로 대조합니다.')
    ap.add_argument('source', help='원본 .pptx 또는 .pdf')
    ap.add_argument('html')
    ap.add_argument('--report', help='결과를 저장할 txt 파일')
    args = ap.parse_args()

    sp = Path(args.source)
    if not sp.is_file():
        sys.exit(f'[오류] 원본 파일이 없습니다: {sp}')
    src = pdf_paragraphs(sp) if sp.suffix.lower() == '.pdf' else pptx_paragraphs(sp)
    try:
        html = Path(args.html).read_text(encoding='utf-8')
    except (FileNotFoundError, UnicodeDecodeError) as e:
        sys.exit(f'[오류] HTML 을 읽을 수 없습니다: {e}')
    parser = SectionText()
    parser.feed(html)
    added = sum(1 for x in parser.slides if x['added'])
    out_slides = [x for x in parser.slides if not x['added']]

    lines = [f'원본 {len(src)}장 · 결과 {len(out_slides)}장' + (f' (새로 넣은 장 {added}개 제외)' if added else '')]
    if len(src) != len(out_slides):
        lines.append('[확인 필요] 장 수가 다릅니다. 같은 번호끼리 대조하므로 뒤쪽 결과가 어긋날 수 있습니다.')

    # 모든 장의 절반 이상에 반복되는 문구(푸터·저작권 등)는 대조에서 뺀다
    freq = Counter(t for sl in src for t in set(sl))
    common = {t for t, c in freq.items() if len(src) >= 4 and c >= len(src) / 2}
    if common:
        lines.append('반복 문구로 제외: ' + ' / '.join(sorted(common))[:200])

    total_miss = total_part = total_num = 0
    for i, paras in enumerate(src):
        if i >= len(out_slides):
            lines.append(f'\n[{i + 1}장] 결과에 이 장이 없습니다.')
            total_miss += len(paras)
            continue
        text = ' '.join(out_slides[i]['text'])
        extra = ' '.join(out_slides[i]['extra'])
        nt, all_nums = norm(text), nums(text + ' ' + extra)
        nall = norm(text + ' ' + extra).replace(',', '')
        miss, part, moved, mnum = [], [], [], set()
        for p in paras:
            if p in common:
                continue
            if norm(p) and norm(p) in nt:
                continue
            words = [w for w in re.split(r'\s+', p) if len(norm(w)) >= 2]
            hit = sum(1 for w in words if norm(w) in nt)
            hit_all = sum(1 for w in words if norm(w) in nall or norm(w).replace(',', '') in nall)
            if words and hit / len(words) >= 0.9:
                part.append(p)
            elif words and hit_all == len(words):
                moved.append(p)
            else:
                miss.append(p)
        for p in paras:
            if p not in common:
                mnum |= nums(p) - all_nums
        if miss or part or moved or mnum:
            lines.append(f'\n[{i + 1}장] 빠짐 {len(miss)} · 부분 일치 {len(part)} · 차트·숫자 칸으로 옮김 {len(moved)} · 빠진 숫자 {len(mnum)}')
            lines += [f'  - 빠짐: {p}' for p in miss]
            lines += [f'  - 부분 일치: {p}' for p in part]
            lines += [f'  - 옮김(정상 여부 확인): {p}' for p in moved]
            if mnum:
                lines.append('  - 빠진 숫자: ' + ', '.join(sorted(mnum)))
        total_miss, total_part, total_num = total_miss + len(miss), total_part + len(part), total_num + len(mnum)

    lines.insert(1, f'합계: 빠짐 {total_miss} · 부분 일치 {total_part} · 빠진 숫자 {total_num}'
                    + ('  → 모두 일치' if not (total_miss or total_num) else ''))
    report = '\n'.join(lines)
    print(report)
    if args.report:
        try:
            Path(args.report).write_text(report, encoding='utf-8')
            print(f'\n저장: {args.report}')
        except OSError as e:
            print(f'[경고] 결과 파일 저장 실패: {e}')


if __name__ == '__main__':
    main()
