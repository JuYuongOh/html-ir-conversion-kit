"""결과 HTML의 레이아웃 검사(D 키와 같은 검사)를 브라우저 없이 실행하고, 장별 스크린샷을 저장한다.

사용법:
    python tools/check_layout.py projects/<회사명>/<결과>.html [--shots 폴더] [--only 3,5,7]

    --shots: 장마다 1600×900 PNG를 저장한다 (시각 자체 검수표를 쓸 때 AI가 직접 본다).
    --only : 스크린샷을 찍을 장 번호 (쉼표 구분). 없으면 전체.
필요:
    playwright. 없으면 처음 실행할 때 자동으로 설치한다 (tools/deps.py).
    브라우저는 PC의 Edge·Chrome을 먼저 쓰고, 없을 때만 Chromium을 내려받는다.
출력:
    장마다 문제 목록. 문제 없으면 "문제 없음". 자리표시가 남은 장은 그대로 알려준다.
"""
import sys
import json
import argparse
from pathlib import Path

import deps

sys.stdout.reconfigure(encoding='utf-8')
FALLBACK = '       설치할 수 없으면 결과 HTML을 브라우저로 열고 D 키 → "결과 복사" 내용을 대화에 붙여넣으세요.'


def load_playwright():
    if not deps.ensure('playwright'):
        sys.exit('[오류] playwright 를 설치하지 못했습니다.\n' + FALLBACK)
    from playwright.sync_api import sync_playwright
    return sync_playwright


def launch(p):
    """Chromium → PC에 설치된 Edge·Chrome 순서로 띄운다. 모두 없을 때만 Chromium 을 자동 설치한다."""
    for kw in ({}, {'channel': 'msedge'}, {'channel': 'chrome'}):
        try:
            return p.chromium.launch(**kw)
        except Exception:  # playwright Error: 해당 브라우저가 없음
            continue
    if not deps.ensure_chromium():
        sys.exit('[오류] 검사용 브라우저를 찾거나 설치하지 못했습니다.\n' + FALLBACK)
    return p.chromium.launch()


def run_check(page, url: str) -> dict:
    box: dict = {}

    def on_console(msg) -> None:
        if msg.text.startswith('KIT_CHECK '):
            box['data'] = msg.text[len('KIT_CHECK '):]

    page.on('console', on_console)
    page.goto(url + '#check', wait_until='load')
    for _ in range(60):
        if 'data' in box:
            break
        page.wait_for_timeout(250)
    if 'data' not in box:
        sys.exit('[오류] 검사 결과를 받지 못했습니다. deck_base.html 로 만든 결과 파일인지 확인하세요.')
    if not page.evaluate("typeof Chart !== 'undefined'"):
        print('[안내] Chart.js(CDN)를 불러오지 못해 차트가 비어 보입니다. 인터넷 연결이 되는 곳에서 다시 확인하세요.')
    return json.loads(box['data'])


def save_shots(page, url: str, folder: Path, only: set[int], total: int) -> int:
    folder.mkdir(parents=True, exist_ok=True)
    page.add_init_script("document.addEventListener('DOMContentLoaded',function(){var s=document.createElement('style');"
                         "s.textContent='#rail,#ctrl,#hint,#progress,#kitck{display:none!important}';document.head.appendChild(s);});")
    n = 0
    for i in range(1, total + 1):
        if only and i not in only:
            continue
        page.goto(f'{url}?s={i}#{i}', wait_until='load')  # 쿼리를 바꿔 매번 새로 연다
        page.wait_for_timeout(1500)
        page.screenshot(path=str(folder / f'{i:02d}.png'))
        n += 1
    return n


def main() -> None:
    ap = argparse.ArgumentParser(description='결과 HTML 레이아웃 검사 + 장별 스크린샷')
    ap.add_argument('html')
    ap.add_argument('--shots', help='스크린샷 저장 폴더')
    ap.add_argument('--only', help='스크린샷 장 번호 (예: 3,5,7)')
    args = ap.parse_args()

    path = Path(args.html).resolve()
    if not path.is_file():
        sys.exit(f'[오류] 파일이 없습니다: {path}')
    try:
        only = {int(x) for x in args.only.split(',')} if args.only else set()
    except ValueError:
        sys.exit('[오류] --only 는 쉼표로 구분한 장 번호여야 합니다 (예: 3,5,7)')

    sync_playwright = load_playwright()
    url = path.as_uri()
    try:
        with sync_playwright() as p:
            browser = launch(p)
            page = browser.new_page(viewport={'width': 1600, 'height': 900})
            result = run_check(page, url)
            print(f"레이아웃 검사: {result.get('total', 0)}장 중 {result.get('bad', 0)}장 문제")
            for item in result.get('items', []):
                if item.get('issues'):
                    print(f"[{item['slide']}장] " + ' | '.join(item['issues']))
            if args.shots:
                page2 = browser.new_page(viewport={'width': 1600, 'height': 900})
                n = save_shots(page2, url, Path(args.shots), only, int(result.get('total', 0)))
                print(f'스크린샷 {n}장 저장: {args.shots}')
            browser.close()
    except Exception as e:  # playwright raises its own Error types for launch/navigation failures
        sys.exit(f'[오류] 브라우저 실행 실패: {e}\n' + FALLBACK)


if __name__ == '__main__':
    main()
