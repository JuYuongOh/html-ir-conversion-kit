"""검토용 파일에서 편집해 저장한 '…_편집본.html' 의 고친 장을 slides 조각(NN.html)에 되돌린다.

사용법:
    python tools/apply_edits.py projects/<회사명> <편집본.html 경로>

    편집 모드가 고친 장에만 data-edited 표시를 남기므로, 그 장의 조각만 바꾼다.
    바꾸기 전 조각은 slides/_편집전_<날짜시각>/ 에 그대로 보관한다.
    편집본 안의 내장 이미지는 images/ 의 같은 파일이면 원래 경로(images/…)로 되돌리고,
    새 이미지면 images/edit_<번호>.<확장자> 로 저장해 그 경로를 쓴다.
    끝나면 finalize.py 를 다시 실행해 결과·검토용 파일을 새로 만든다.
"""
import sys
import re
import base64
import hashlib
import mimetypes
from datetime import datetime
from pathlib import Path

import deps
from finalize import read_text, to_data_uri, MAX_BYTES_RAW

sys.stdout.reconfigure(encoding='utf-8')

TAG = re.compile(r'<(/?)section\b[^>]*>', re.I)
DATA_URI = re.compile(r'data:([\w.+/-]+);base64,([A-Za-z0-9+/=]+)')
EDITED = re.compile(r'\sdata-edited="1"')


def top_sections(html: str) -> list[tuple[int, int]]:
    """맨 바깥 <section class="slide …"> … </section> 의 (시작, 끝) 위치 목록."""
    spans, depth, start = [], 0, -1
    for m in TAG.finditer(html):
        if m.group(1):
            depth -= 1
            if depth == 0 and start > -1:
                spans.append((start, m.end()))
                start = -1
        else:
            if depth == 0 and re.search(r'class="slide\b', m.group(0)):
                start = m.start()
            depth += 1
    return spans


def image_map(root: Path) -> dict[str, str]:
    img_dir = root / 'images'
    if not img_dir.is_dir():
        return {}
    files = [f for f in sorted(img_dir.rglob('*')) if f.is_file()]
    if any(f.stat().st_size > MAX_BYTES_RAW for f in files):
        deps.ensure('PIL')
    out: dict[str, str] = {}
    for f in files:
        try:
            out[to_data_uri(f)] = f.relative_to(root).as_posix()
        except OSError as e:
            print(f'[경고] {f.name} 을 읽지 못했습니다: {e}')
    return out


def restore_images(section: str, root: Path, known: dict[str, str]) -> tuple[str, int]:
    added = 0

    def repl(m: re.Match) -> str:
        nonlocal added
        uri = m.group(0)
        if uri in known:
            return known[uri]
        raw = base64.b64decode(m.group(2))
        ext = (mimetypes.guess_extension(m.group(1)) or '.bin').replace('.jpe', '.jpg')
        rel = f'images/edit_{hashlib.sha1(raw).hexdigest()[:8]}{ext}'
        path = root / rel
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            added += 1
        known[uri] = rel
        return rel

    return DATA_URI.sub(repl, section), added


def main() -> None:
    if len(sys.argv) != 3:
        sys.exit('사용법: python tools/apply_edits.py projects/<회사명> <편집본.html>')
    root, edited_path = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    slides_dir = root / 'slides'
    if not slides_dir.is_dir():
        sys.exit(f'[오류] slides 폴더가 없습니다: {slides_dir}')
    edited = read_text(edited_path)
    body = edited[edited.find('<body'):]
    new_spans = top_sections(body)
    if not new_spans:
        sys.exit('[오류] 편집본에서 장(<section class="slide">)을 찾지 못했습니다.')

    files = [p for p in sorted(slides_dir.glob('*.html')) if not p.name.startswith('00')]
    owners: list[tuple[Path, int]] = []  # 편집본의 n번째 장 → (조각 파일, 파일 안 순번)
    for p in files:
        owners += [(p, k) for k in range(len(top_sections(read_text(p))))]
    if len(owners) != len(new_spans):
        sys.exit(f'[중단] 장 수가 다릅니다: 조각 {len(owners)}장 · 편집본 {len(new_spans)}장. '
                 '편집본을 만든 뒤 장 조각이 바뀌었는지 확인하세요. 아무것도 바꾸지 않았습니다.')

    changed = [i for i, (a, b) in enumerate(new_spans) if EDITED.search(body[a:body.find('>', a) + 1])]
    if not changed:
        print('편집본에 고친 장이 없습니다. 바꾼 파일 없음.')
        return

    known = image_map(root)
    backup = slides_dir / f'_편집전_{datetime.now():%Y%m%d-%H%M%S}'
    texts: dict[Path, str] = {}
    n_img = 0
    for i in changed:
        a, b = new_spans[i]
        sec, added = restore_images(EDITED.sub('', body[a:b], count=1), root, known)
        n_img += added
        path, k = owners[i]
        text = texts.get(path) or read_text(path)
        s, e = top_sections(text)[k]
        texts[path] = text[:s] + sec + text[e:]
    try:
        backup.mkdir(parents=True, exist_ok=False)
        for path, text in texts.items():
            (backup / path.name).write_text(read_text(path), encoding='utf-8')
            path.write_text(text, encoding='utf-8')
    except OSError as e:
        sys.exit(f'[오류] 저장 실패: {e}')

    print(f'완료: {len(changed)}장 반영 ({", ".join(str(i + 1) + "장" for i in changed)})')
    print(f'  바꾼 조각: {", ".join(p.name for p in texts)} · 이전 조각 보관: slides/{backup.name}/')
    if n_img:
        print(f'  새 이미지 {n_img}개를 images/ 에 저장했습니다.')
    print('  다음: python tools/finalize.py ' + sys.argv[1] + ' 로 다시 조립하세요.')


if __name__ == '__main__':
    main()
