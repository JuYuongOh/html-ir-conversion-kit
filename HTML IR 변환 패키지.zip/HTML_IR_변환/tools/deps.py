"""필요한 파이썬 패키지와 검사용 브라우저(Chromium)를 처음 쓸 때 자동으로 설치한다.

다른 도구(finalize·verify_text·check_layout)가 불러 쓴다. 이미 설치된 것은 건너뛰므로 여러 번 실행해도 된다.
"""
import sys
import subprocess
import importlib
import importlib.util

sys.stdout.reconfigure(encoding='utf-8')

PIP_NAME = {'pptx': 'python-pptx', 'pdfplumber': 'pdfplumber', 'PIL': 'pillow', 'playwright': 'playwright'}


def _pip(names: list[str]) -> bool:
    base = [sys.executable, '-m', 'pip', 'install', '--quiet', '--disable-pip-version-check']
    for extra in ([], ['--user']):  # 관리자 권한이 없어 실패하면 사용자 폴더에 다시 설치
        try:
            if subprocess.run(base + extra + names).returncode == 0:
                return True
        except OSError as e:
            print(f'[경고] pip 실행 실패: {e}')
            return False
    return False


def ensure(*modules: str) -> bool:
    """modules(import 이름) 중 없는 것을 설치한다. 모두 쓸 수 있으면 True."""
    missing = [m for m in modules if importlib.util.find_spec(m) is None]
    if not missing:
        return True
    names = [PIP_NAME.get(m, m) for m in missing]
    print(f'[자동 설치] {", ".join(names)} 를 설치합니다 (처음 한 번만, 1~2분).')
    if not _pip(names):
        print(f'[경고] 자동 설치에 실패했습니다. 직접 실행하세요: python -m pip install {" ".join(names)}')
        return False
    importlib.invalidate_caches()
    return all(importlib.util.find_spec(m) is not None for m in modules)


def ensure_chromium() -> bool:
    """playwright 용 Chromium 을 설치한다 (이미 있으면 바로 끝남)."""
    print('[자동 설치] 검사용 브라우저(Chromium)를 준비합니다 (처음 한 번만, 1~3분).')
    try:
        ok = subprocess.run([sys.executable, '-m', 'playwright', 'install', 'chromium']).returncode == 0
    except OSError as e:
        print(f'[경고] Chromium 설치 실패: {e}')
        return False
    if not ok:
        print('[경고] Chromium 설치에 실패했습니다. 직접 실행하세요: python -m playwright install chromium')
    return ok


def ensure_all() -> bool:
    """패키지 4종을 설치한다. 브라우저는 check_layout 이 Edge·Chrome 을 먼저 쓰므로 여기서 받지 않는다."""
    ok = ensure('pptx', 'pdfplumber', 'PIL', 'playwright')
    print('준비 완료' if ok else '일부 설치 실패 (위 경고 참고)')
    return ok


if __name__ == '__main__':
    sys.exit(0 if ensure_all() else 1)
