"""IR HTML 덱 조립·내장 스크립트 (지침 3~5단계에서 사용)

사용법:
    python tools/finalize.py projects/<회사명> [--out 결과파일.html] [--online] [--review 원본이미지폴더]

    --review: 원본 장 이미지(PowerPoint에서 'PNG로 내보내기' 한 슬라이드1.png, 슬라이드2.png …)가 든 폴더.
              주지 않아도 작업폴더에 '원본' 폴더가 있으면 그것을 쓴다. 검토용 파일에서 O 키를 누르면 원본을 나란히 보여준다.

    결과와 함께 항상 '…_검토용.html' 을 만든다. 검토용 파일에서 E 키를 누르면 편집 모드가 켜진다
    (글 수정 · 끌어서 이동 · 크기 조절 · 되돌리기 · 저장). 저장한 '…_편집본.html' 은
    python tools/apply_edits.py projects/<회사명> <편집본.html> 로 slides 조각에 되돌린다.

작업폴더 구조:
    slides/00_설정.html     <title>…</title> 과 <style id="brand">:root{…}</style>
    slides/01.html …        장마다 <section class="slide …">…</section> 조각 (파일 이름 순서대로 들어감)
    images/…                원본에서 뽑은 이미지 (조각 안에서 src="images/파일명" 으로 참조)
    원본/                    (선택) 원본 장 이미지

deck_base.html · pretendard_embed.css · review_editor.js 는 작업폴더 → 이 스크립트 폴더 → ../kit 순서로 찾는다.
"""
import sys
import re
import base64
import argparse
import mimetypes
from io import BytesIO
from pathlib import Path
from typing import Optional

import deps

sys.stdout.reconfigure(encoding='utf-8')

PH_WORDS = ['자리표시', '항목 제목', '세부 항목', '지표 라벨', 'COMPANY NAME', 'Company Name', 'YYYY',
            '00단위', '자료 이미지', '단계 이름', '근거 항목']
FONT_BLOCK = re.compile(r'/\*@@FONT-START@@\*/.*?/\*@@FONT-END@@\*/', re.S)
IMG_SRC = re.compile(r'''(src=|url\()(["']?)(images/[^"')]+)\2''')
MAX_BYTES_RAW = 300_000


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding='utf-8')
    except FileNotFoundError:
        sys.exit(f'[오류] 파일이 없습니다: {path}')
    except UnicodeDecodeError:
        sys.exit(f'[오류] UTF-8로 읽을 수 없습니다: {path}')


GATE_HELP = ('  단계 잠금(AGENTS.md §0): 사용자가 다음 단계 명령을 말한 뒤에만 _진행상태.md 의 값을 올린다.\n'
             '  AI는 이 메시지를 받으면 조각을 지우거나 값을 바꾸지 말고, 멈추고 사용자에게 보고한다.')


def check_gate(root: Path, n_slides: int) -> None:
    """_진행상태.md 의 단계가 3(제작)보다 작으면 조립하지 않고 멈춘다."""
    state = root / '_진행상태.md'
    if not state.is_file():
        sys.exit('[중단] _진행상태.md 가 없습니다. docs/진행상태_양식.md 를 복사해 1단계부터 진행하세요.\n'
                 '  (사람이 직접 조립하는 경우에는 파일에 "단계: 5" 를 적으면 됩니다.)')
    text = re.sub(r'<!--.*?-->', '', read_text(state), flags=re.S)  # 설명 주석은 빼고 읽는다

    def val(key: str, default: str) -> str:
        m = re.search(rf'^{key}\s*:\s*(\S+)\s*$', text, re.M)
        return m.group(1) if m else default

    try:
        stage = int(val('단계', '1'))
    except ValueError:
        sys.exit('[중단] _진행상태.md 의 단계 값은 숫자여야 합니다.')
    if val('전체진행', '아니오').startswith('예') or stage >= 3:
        return
    sys.exit(f'[중단] 지금은 {stage}단계입니다. 조립은 사용자가 "제작 시작"을 승인한 3단계부터 합니다.\n' + GATE_HELP)


def find_asset(name: str, root: Path) -> Optional[Path]:
    here = Path(__file__).resolve().parent
    for d in (root, here, here.parent / 'kit', root.parent.parent / 'kit'):
        if (d / name).is_file():
            return d / name
    return None


def load_settings(slides_dir: Path) -> tuple[str, str]:
    files = sorted(p for p in slides_dir.glob('00*.html'))
    if not files:
        print('[경고] slides/00_설정.html 이 없어 제목·브랜드 색을 기본값으로 둡니다.')
        return 'IR Deck', ''
    text = read_text(files[0])
    m_title = re.search(r'<title>(.*?)</title>', text, re.S)
    m_brand = re.search(r'<style[^>]*id=["\']brand["\'][^>]*>.*?</style>', text, re.S)
    if not m_brand:
        print('[경고] 00_설정.html 에 <style id="brand"> 가 없습니다. 킷 기본 색이 쓰입니다.')
    return (m_title.group(1).strip() if m_title else 'IR Deck'), (m_brand.group(0) if m_brand else '')


def collect_slides(slides_dir: Path) -> list[tuple[str, str]]:
    out = []
    for p in sorted(slides_dir.glob('*.html')):
        if p.name.startswith('00'):
            continue
        text = read_text(p)
        n = text.count('<section')
        if n == 0:
            print(f'[경고] {p.name}: <section> 이 없어 건너뜁니다.')
            continue
        if text.count('</section>') != n:
            print(f'[경고] {p.name}: <section> 여닫기 수가 맞지 않습니다. 결과를 확인하세요.')
        out.append((p.name, text.strip()))
    return out


def to_data_uri(path: Path) -> str:
    raw = path.read_bytes()
    mime = mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
    if len(raw) > MAX_BYTES_RAW and mime in ('image/png', 'image/jpeg', 'image/bmp'):
        try:
            from PIL import Image
            with Image.open(BytesIO(raw)) as im:
                im = im.convert('RGBA') if im.mode in ('P', 'LA') else im
                if im.width > 1600:
                    im = im.resize((1600, round(im.height * 1600 / im.width)))
                buf = BytesIO()
                im.save(buf, 'WEBP', quality=82)
                raw, mime = buf.getvalue(), 'image/webp'
        except ImportError:
            print(f'[안내] Pillow 가 없어 {path.name} 을 원본 크기로 넣습니다.')
        except OSError as e:
            print(f'[경고] {path.name} 변환 실패, 원본으로 넣습니다: {e}')
    return f'data:{mime};base64,' + base64.b64encode(raw).decode()


def embed_images(html: str, root: Path) -> tuple[str, int, list[str]]:
    cache: dict[str, str] = {}
    missing: list[str] = []

    def repl(m: re.Match) -> str:
        rel = m.group(3)
        if rel not in cache:
            p = root / rel
            if not p.is_file():
                missing.append(rel)
                return m.group(0)
            cache[rel] = to_data_uri(p)
        return f'{m.group(1)}{m.group(2)}{cache[rel]}{m.group(2)}'

    return IMG_SRC.sub(repl, html), len(cache), sorted(set(missing))


def inject_editor(html: str, root: Path) -> tuple[str, bool]:
    """편집 모드 스크립트(kit/review_editor.js)를 발표 스크립트보다 앞(#hint 뒤 첫 <script> 앞)에 넣는다."""
    js_path = find_asset('review_editor.js', root)
    if js_path is None:
        print('[경고] review_editor.js 를 찾지 못해 검토용 파일에 편집 모드를 넣지 않았습니다.')
        return html, False
    js = read_text(js_path)
    if '</script' in js.lower():
        print('[경고] review_editor.js 안에 </script 문자열이 있어 넣지 않았습니다.')
        return html, False
    hint = html.rfind('<div id="hint"')
    at = html.find('<script', hint) if hint > -1 else -1
    if at < 0:
        print('[경고] deck_base.html 의 #hint 뒤 스크립트 위치를 찾지 못해 편집 모드를 넣지 않았습니다.')
        return html, False
    return html[:at] + f'<script id="kit-editor">\n{js}\n</script>\n' + html[at:], True


def write_review(html: str, folder: Optional[Path], out: Path, root: Path) -> None:
    """검토용 파일: 편집 모드(E 키)는 항상, 원본 나란히 보기(O 키)는 원본 장 이미지가 있을 때 넣는다."""
    pages: dict[int, str] = {}
    if folder is not None:
        if not folder.is_dir():
            print(f'[경고] 원본 이미지 폴더가 없습니다: {folder}  (O 키 원본 비교 없이 만듭니다)')
        else:
            for p in sorted(folder.iterdir()):
                m = re.search(r'(\d+)', p.stem)
                if m and p.suffix.lower() in ('.png', '.jpg', '.jpeg', '.webp'):
                    pages.setdefault(int(m.group(1)), to_data_uri(p))
            if not pages:
                print(f'[경고] {folder} 에 번호가 붙은 이미지가 없습니다 (예: 슬라이드1.png).')
    review, has_editor = inject_editor(html, root)
    if pages:
        js = 'window.KIT_ORIG={' + ','.join(f'{k}:"{v}"' for k, v in sorted(pages.items())) + '};'
        at = review.rfind('</body>')
        review = review[:at] + f'<script>{js}</script>\n' + review[at:]
    if not pages and not has_editor:
        return
    rpath = out.with_name(out.stem + '_검토용.html')
    try:
        rpath.write_text(review, encoding='utf-8')
    except OSError as e:
        print(f'[경고] 검토용 파일 저장 실패: {e}')
        return
    keys = (['E 키 편집'] if has_editor else []) + ([f'O 키 원본 {len(pages)}장 나란히 보기'] if pages else [])
    print(f'검토용: {rpath.name}  ({" · ".join(keys)})')


def main() -> None:
    ap = argparse.ArgumentParser(description='slides 조각을 deck_base.html 에 넣고 폰트·이미지를 내장합니다.')
    ap.add_argument('folder', nargs='?', default='.', help='작업폴더 (기본: 현재 폴더)')
    ap.add_argument('--out', help='결과 파일 이름 (기본: 제목.html)')
    ap.add_argument('--online', action='store_true', help='폰트를 내장하지 않고 CDN 그대로 둠')
    ap.add_argument('--review', help='원본 장 이미지 폴더 (검토용 파일을 따로 만듦)')
    args = ap.parse_args()

    root = Path(args.folder).resolve()
    base_path = find_asset('deck_base.html', root)
    if base_path is None:
        sys.exit('[오류] deck_base.html 을 찾지 못했습니다 (작업폴더 · tools · kit 폴더 확인).')
    base = read_text(base_path)
    slides_dir = root / 'slides'
    if not slides_dir.is_dir():
        sys.exit(f'[오류] slides 폴더가 없습니다: {slides_dir}')
    if '<!--@@SLIDES@@-->' not in base:
        sys.exit('[오류] deck_base.html 에 <!--@@SLIDES@@--> 표시가 없습니다. 원본 deck_base.html 을 쓰세요.')

    title, brand = load_settings(slides_dir)
    slides = collect_slides(slides_dir)
    if not slides:
        sys.exit('[오류] 넣을 장 조각이 없습니다.')
    check_gate(root, len(slides))

    html = base.replace('@@TITLE@@', title).replace('<!--@@BRAND@@-->', brand)
    html = html.replace('<!--@@SLIDES@@-->', '\n'.join(t for _, t in slides))

    font_note = 'CDN'
    emb = find_asset('pretendard_embed.css', root)
    if not args.online and emb is not None:
        block = '/*@@FONT-START@@*/\n' + read_text(emb) + '\n/*@@FONT-END@@*/'
        html, n = FONT_BLOCK.subn(lambda _: block, html, count=1)
        font_note = '내장' if n else 'CDN (표시 블록을 찾지 못함)'

    img_dir = root / 'images'
    if img_dir.is_dir() and any(f.stat().st_size > MAX_BYTES_RAW for f in img_dir.rglob('*') if f.is_file()):
        deps.ensure('PIL')  # 큰 이미지를 webp 로 줄이는 데 씀
    html, n_img, missing = embed_images(html, root)

    name = args.out or (re.sub(r'[\\/:*?"<>|]+', '_', title).strip() or 'IR_Deck') + '.html'
    out = root / name
    try:
        out.write_text(html, encoding='utf-8')
    except OSError as e:
        sys.exit(f'[오류] 저장 실패: {e}')

    review_dir = Path(args.review) if args.review else root / '원본'
    write_review(html, review_dir if (args.review or review_dir.is_dir()) else None, out, root)

    print(f'완료: {out.name}  ({len(html.encode()) / 1_048_576:.1f} MB)')
    n_sec = html.count('<section class="slide')
    print(f'  장 수 {n_sec} · 조각 파일 {len(slides)}개 · 이미지 내장 {n_img}개 · 폰트 {font_note}')
    if missing:
        print('  [확인 필요] images 폴더에 없는 이미지: ' + ', '.join(missing))
    visible = re.sub(r'<(script|style)[^>]*>.*?</\1>', ' ', html.split('<body>', 1)[-1], flags=re.S)
    left = [w for w in PH_WORDS if w in re.sub(r'<[^>]+>', ' ', visible)]
    if left or 'data-ph=' in html:
        print('  [확인 필요] 디자인 킷 자리표시가 남아 있습니다: ' + ', '.join(left + (['자리표시 이미지'] if 'data-ph=' in html else [])))
    classes = re.findall(r'<section class="slide ([^"]*)"', html)
    if classes and 'cover' not in classes[0].split():
        print('  [확인 필요] 첫 장이 표지(class="slide cover")가 아닙니다. 표지는 원본에 없어도 반드시 넣습니다.')
    if classes and 's-end' not in classes[-1].split():
        print('  [확인 필요] 마지막 장이 감사합니다 장(class="slide s-end")이 아닙니다. 원본에 없어도 반드시 넣습니다.')
    print('  브라우저로 열고 D 키를 눌러 레이아웃 검사를 하세요.')


if __name__ == '__main__':
    main()
